package com.example.arduinowebviewtestamd

import android.graphics.Bitmap
import android.net.http.SslError
import android.os.Bundle
import android.os.Message
import android.view.Gravity
import android.webkit.*
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.arduinowebviewtestamd.databinding.ActivityMainBinding


class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        //Sets theme to regular theme after splash screen.
        //Splash screen is activated in AndroidManifest.xml
        setTheme(R.style.Theme_ArduinoWebViewTestAMD)
        setContentView(binding.root)

        //Hide action bar
        //this.supportActionBar!!.hide()
        supportActionBar?.hide()

        Toast.makeText(applicationContext, "    Make sure you are connected to \nLora Rescue Mobile Node using WiFi.", Toast.LENGTH_SHORT).show()
        webViewArduinoSetup()

        binding.imageButtonRefresh.setOnClickListener {
            binding.webViewArduino.reload()
            Toast.makeText(applicationContext, "    Make sure you are connected to \nLora Rescue Mobile Node using WiFi.", Toast.LENGTH_SHORT).show()
        }

    }

    private fun webViewArduinoSetup() {


        binding.webViewArduino.webViewClient = MyWebViewClient(this)

        binding.webViewArduino.apply {
            loadUrl("192.168.4.1")
            settings.javaScriptEnabled = true

            //Zoom controls
            settings.setSupportZoom(false)
            settings.builtInZoomControls = false
            settings.displayZoomControls = false

            // Enable responsive layout
            settings.useWideViewPort = true
            // Zoom out if the content width is greater than the width of the viewport
            settings.loadWithOverviewMode = true
        }
    }

    class MyWebViewClient internal constructor(private val activity: MainActivity) : WebViewClient() {

//        override fun onReceivedError(
//            view: WebView?,
//            request: WebResourceRequest?,
//            error: WebResourceError?
//        ) {
//            //super.onReceivedError(view, request, error)
//            Toast.makeText(activity, "Network Error. Please connect to Lora Rescue Mobile Node using WiFi.", Toast.LENGTH_LONG).show()
//        }
//
//        override fun onReceivedHttpError(
//            view: WebView?,
//            request: WebResourceRequest?,
//            errorResponse: WebResourceResponse?
//        ) {
//            //super.onReceivedHttpError(view, request, errorResponse)
//            Toast.makeText(activity, "Network Error. Please connect to Lora Rescue Mobile Node using WiFi.", Toast.LENGTH_LONG).show()
//        }
//
//        override fun onReceivedSslError(
//            view: WebView?,
//            handler: SslErrorHandler?,
//            error: SslError?
//        ) {
//            //super.onReceivedSslError(view, handler, error)
//            Toast.makeText(activity, "Network Error. Please connect to Lora Rescue Mobile Node using WiFi.", Toast.LENGTH_LONG).show()
//        }

//        override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
//            //super.onPageStarted(view, url, favicon)
//            Toast.makeText(activity, "    Make sure you are connected to \nLora Rescue Mobile Node using WiFi.", Toast.LENGTH_SHORT).show()
//        }

    }
}